# Houston PI Vision → IDMP Canvas — DEMO PACK

**Use this ZIP (not the built-in example):**  
`~/Desktop/houston-refinery-pivision-demo.zip`

**Migration Studio:** http://127.0.0.1:8765  
**Start live data before you publish** (leave this terminal open):

```bash
cd ~/tdengine-idmp-deployment/agentic-pi-migration
python3 scenarios/examples/houston-refinery-pivision/start-demo-data.py
```

---

## Demo click path (do this live)

1. Open Migration Studio → Connect to `http://localhost:6842` (your usual login)
2. Upload **`houston-refinery-pivision-demo.zip`**
3. Paste the **Global design direction** prompt below
4. Check **Create new**
5. Click **Publish / Migrate**
6. Open the returned Canvas dashboard URL
7. Say the talk track while pointing at feed → column → outlets → live trends

---

## Prompt (paste into “Global design direction”)

```text
Recreate the PI Vision Houston Refinery Unit 3-1415 display as a dark industrial P&ID Canvas. Preserve the left-to-right process flow: feed control into C-1309, LC-780 transfer, side column, P-24/09A pump, and three orthogonal product outlets FC-010 (Plant), FC-011, FC-012 (Storage). Use animated pipelines, live PV/SP Formula bindings with gpm units, Feed QC composition card, a top-right Flow Control Valve Readings trend, and a bottom Feed Flow trend. Keep spacing grid-aligned and operator-friendly. Prefer IDMP 3D metallic symbols (3-D ball valves, vertical storage-tank vessels) to match the PI Vision look. Stay visually close to the source screenshot in the upload.
```

---

## What you say (≈ 2 minutes)

### 1) Setup beat — while Studio is open (15s)

> “Customers don’t want us to rebuild PI Vision by hand.  
> They hand us a folder — screenshot plus tags — we zip it, drop it here, and migrate.”

Upload the ZIP as you say this.

### 2) Prompt beat (10s)

> “This global design direction tells the agent the visual intent.  
> The exact layout still comes from `display.json` in the ZIP — screenshot + tags + Canvas plan.”

Paste the prompt.

### 3) Publish beat (10s)

> “Create new — publish.”

Click Publish. Wait for the result URL.

### 4) Open the Canvas (20s)

> “This is Houston Refinery Unit 3-1415 — the same operator mental model as PI Vision, now inside IDMP.”

Point left → right:

> “Feed in… main column C-1309… LC-780… side column… pump P-24/09A… three product lines to Plant and Storage.”

### 5) Live data beat (20s)

> “These aren’t static labels. PV and SP are live Formula bindings on GTU historian tags — updating every couple of seconds.”

Point at **Flow Control Valve Readings**, then **Feed Flow**:

> “Same trend story PI Vision had — product valves up here, feed scheduled vs actual down here.”

### 6) Editable proof (25s)

Open the Canvas editor:

> “Critical difference from a PNG or a GIF: this is a native Meta2d Canvas.  
> Every pipe, valve, and value is editable. We migrated — we didn’t freeze a picture.”

Optional:

> “Screenshot for likeness. Tags for live data. Canvas for ownership.”

### 7) Close (15s)

> “So the pitch is simple: keep the display operators already trust, put it on TDengine IDMP with live history, and leave it editable for the plant team.  
> Happy to walk the ZIP contents or a tag binding next.”

---

## Fallback lines

**If trends look empty:**

> “Data simulator wasn’t running — one second…”  
Then start `start-demo-data.py` and refresh.

**If publish says name already exists:**

> “We’ll create under a fresh name.”  
Re-publish with **Create new** still checked, or rename the display in Studio if shown.

**If someone asks “is this computer vision?”:**

> “No — screenshot-guided. The ZIP carries the structured Canvas plan and tag map. That’s how we get exact, repeatable migrations.”
