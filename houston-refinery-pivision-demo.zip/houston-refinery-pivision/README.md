# What you feed Agentic PI Migration

You don’t feed it a chat prompt alone.  
You feed it a **small folder** (zipped) with three real pieces:

| File | What it is | Why it matters |
|------|------------|----------------|
| `screenshot.jpg` | Picture of the PI Vision display | Shows **what it should look like** |
| `tags.csv` | List of charts + PI tag names | Shows **what live data to bind** |
| `display.json` | Canvas layout plan (pipes, valves, labels, chart positions) | Shows **exactly where everything goes** |

```text
houston-refinery-pivision-demo.zip
└── houston-refinery-pivision/
    ├── screenshot.jpg   ← “look like this”
    ├── tags.csv         ← “bind these tags”
    └── display.json     ← “build this layout”
```

## What AI is it using?

**IDMP’s built-in AI panel service** — called through the IDMP REST API:

`POST /api/v1/ai/panels/create`

That is **TDengine IDMP Agentic AI** on your IDMP instance (the same AI used inside IDMP to build panels).  
This migration tool does **not** call ChatGPT / Claude / Cursor by itself when you click Publish.

If IDMP AI is unavailable, the tool falls back to a safe default: it builds the chart directly from the tags you listed in `tags.csv`.

The **Global design direction** text you paste in Migration Studio is extra guidance. It gets attached to the panel prompt when that IDMP AI path runs.

## How does it “come to conclusions”?

Short answer: **from the files you gave it**, not by guessing from the screenshot.

| Question | How the tool decides |
|----------|----------------------|
| What should the P&ID look like? | Reads **`display.json`** (pipes, equipment, labels, positions). Deterministic — same ZIP → same layout. |
| Which values/trends are live? | Reads **`tags.csv`** (tag names → IDMP attributes). |
| What should it resemble? | Uses **`screenshot.jpg`** as a visual reference for people / agents preparing the ZIP. It is **not** computer vision that auto-traces the image. |
| Chart style / wording? | Uses the row `prompt` in `tags.csv` + optional Global design direction → IDMP AI (when used). |

So the logic is:

1. **Screenshot** = human reference (“match this look”)  
2. **Tags** = data contract (“these historian points”)  
3. **Display plan** = exact Canvas structure (“draw it here”)  
4. **IDMP AI** = helps generate chart panels when explicit series aren’t enough  
5. **REST publish** = creates the live editable Canvas on IDMP  

That is why re-uploading the same ZIP produces the **same** Houston display.

## In one sentence

**You supply the picture, the tags, and the layout plan; IDMP’s Agentic AI helps build chart panels; the migrator publishes a live editable Canvas over REST.**

## 3D symbols (like PI Vision)

The Canvas uses **IDMP’s built-in 3D metallic symbol library** (same assets as the editor symbol pane):

- Valves → `3-D Ball valve（三维球阀）`
- Columns → `Storage tank（储罐）` (vertical 3D vessel)

So it reads as industrial 3D equipment, not flat shapes.

## How to run this demo

1. Migration Studio → http://127.0.0.1:8765  
2. Upload `houston-refinery-pivision-demo.zip`  
3. Paste the prompt from `DEMO_SCRIPT.md` (optional guidance)  
4. Check **Create new** → Publish  
5. Open the Canvas link  

For moving numbers:

```bash
python3 start-demo-data.py
```
