#!/usr/bin/env python3
"""Precision-grid Houston Unit 3-1415 Canvas — orthogonal pipes only."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

ELEMENT_ID = 2026702359773696
DASHBOARD_ID = None
DISPLAY_NAME = "Houston Refinery Unit 3-1415 (ZIP Demo)"

WIDTH = 1920
HEIGHT = 1000

BG = "#121826"
FRAME = "#5f7a96"
TEXT = "#f5f7fa"
MUTED = "#9eb0c3"
CYAN = "#3dd6ff"
LIVE = "#5dffb0"
PIPE = "#7ec8ff"
ACCENT = "#1e90ff"
VALVE = "/static/png/IoT-valve symbols（阀门符号）/3-D Ball valve（三维球阀）.svg"
COLUMN = "/static/png/IoT-water tank（水槽）/Storage tank（储罐）.svg"
PUMP_BODY = "/static/png/IoT-water tank（水槽）/Drum（滚筒）.svg"


def snap(value: float, step: int = 10) -> float:
    return float(round(value / step) * step)


def rect(
    pen_id: str,
    x: float,
    y: float,
    w: float,
    h: float,
    *,
    background: str,
    color: str = FRAME,
    line_width: float = 1.5,
    radius: float = 0,
    dash: list[float] | None = None,
) -> dict[str, Any]:
    pen: dict[str, Any] = {
        "id": pen_id,
        "name": "rectangle",
        "x": snap(x),
        "y": snap(y),
        "width": snap(w),
        "height": snap(h),
        "background": background,
        "color": color,
        "lineWidth": line_width,
        "borderRadius": radius,
        "text": "",
        "disableAnchor": True,
    }
    if dash:
        pen["lineDash"] = dash
    return pen


def label(
    pen_id: str,
    x: float,
    y: float,
    w: float,
    h: float,
    text: str,
    *,
    size: float = 15,
    color: str = TEXT,
    align: str = "left",
    weight: str = "normal",
) -> dict[str, Any]:
    return {
        "id": pen_id,
        "name": "text",
        "x": snap(x),
        "y": snap(y),
        "width": w,
        "height": h,
        "text": text,
        "color": color,
        "fontSize": size,
        "fontWeight": weight,
        "textAlign": align,
        "disableAnchor": True,
    }


def hv(
    pens: list[dict[str, Any]],
    pen_id: str,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
    *,
    color: str = PIPE,
    width: float = 3,
    animated: bool = True,
    dashed: bool = False,
) -> None:
    """Draw a single strictly horizontal or vertical segment."""
    x1, y1, x2, y2 = snap(x1), snap(y1), snap(x2), snap(y2)
    assert x1 == x2 or y1 == y2, f"non-orthogonal segment {pen_id}: {(x1,y1)}→{(x2,y2)}"
    dx = abs(x2 - x1)
    dy = abs(y2 - y1)
    start_x = 0.0 if x1 <= x2 else 1.0
    end_x = 1.0 - start_x
    start_y = 0.0 if y1 <= y2 else 1.0
    end_y = 1.0 - start_y
    if dx == 0:
        start_x = end_x = 0.5
    if dy == 0:
        start_y = end_y = 0.5
    pen: dict[str, Any] = {
        "id": pen_id,
        "name": "line",
        "type": 1,
        "lineName": "line",
        "x": min(x1, x2),
        "y": min(y1, y2),
        "width": max(dx, 1),
        "height": max(dy, 1),
        "lineWidth": width,
        "color": color,
        "anchors": [
            {"id": "0", "x": start_x, "y": start_y, "start": True},
            {"id": "1", "x": end_x, "y": end_y},
        ],
        "lineAnimateType": 1,
        "animateColor": LIVE,
        "animateSpan": 1,
        "keepAnimateState": True,
        "autoPlay": animated,
        "animateShadow": True,
    }
    if dashed:
        pen["lineDash"] = [6, 5]
    pens.append(pen)


def route(
    pens: list[dict[str, Any]],
    prefix: str,
    points: list[tuple[float, float]],
    *,
    dashed: bool = False,
    width: float = 3,
) -> None:
    """Draw an orthogonal polyline through snapped points (axis-aligned elbows only)."""
    for index in range(len(points) - 1):
        x1, y1 = points[index]
        x2, y2 = points[index + 1]
        x1, y1, x2, y2 = snap(x1), snap(y1), snap(x2), snap(y2)
        if x1 == x2 and y1 == y2:
            continue
        if x1 != x2 and y1 != y2:
            # Force elbow: horizontal then vertical.
            mid = (x2, y1)
            hv(pens, f"{prefix}-{index}a", x1, y1, mid[0], mid[1], dashed=dashed, width=width)
            hv(pens, f"{prefix}-{index}b", mid[0], mid[1], x2, y2, dashed=dashed, width=width)
        else:
            hv(pens, f"{prefix}-{index}", x1, y1, x2, y2, dashed=dashed, width=width)


def image(
    pen_id: str,
    x: float,
    y: float,
    w: float,
    h: float,
    source: str,
) -> dict[str, Any]:
    return {
        "id": pen_id,
        "name": "image",
        "x": snap(x),
        "y": snap(y),
        "width": w,
        "height": h,
        "image": source,
        "crossOrigin": "anonymous",
        "disableAnchor": True,
    }


def live(
    pen_id: str,
    x: float,
    y: float,
    w: float,
    h: float,
    attr: str,
    placeholder: str,
    *,
    size: float = 15,
    color: str = LIVE,
) -> dict[str, Any]:
    pen = label(pen_id, x, y, w, h, placeholder, size=size, weight="bold", color=color)
    pen["form"] = [
        {
            "key": "text",
            "name": "value",
            "type": "text",
            "expression": f"${{attributes['{attr}']}}",
            "dataReferenceType": "Formula",
            "expressionElementId": ELEMENT_ID,
        }
    ]
    return pen


def feed_qc_card(pens: list[dict[str, Any]]) -> None:
    """Polished Feed QC card — clearer than flat PI Vision text block."""
    x, y, w, h = 36, 590, 320, 250
    rows = [
        ("Characterization Factor", "11.46"),
        ("API Gravity", "24"),
        ("Heavy Metals", "1,827 ppm"),
        ("Sulfur", "0.798 wt%"),
        ("Conradson Carbon", "0.3 wt%"),
        ("Final Boiling Point", "1,015.2 °F"),
        ("Initial Boiling Point", "406.6 °F"),
    ]
    pens.extend(
        [
            # Soft outer glow frame
            rect("qc-glow", x - 4, y - 4, w + 8, h + 8, background="#0b1220", color=ACCENT, line_width=2, radius=10),
            rect("qc", x, y, w, h, background="#152033", color="#2a5f86", line_width=1.5, radius=8),
            # Header strip
            rect("qc-head", x, y, w, 36, background="#1a3a5c", color="#1a3a5c", line_width=0, radius=8),
            rect("qc-head-accent", x, y, 6, 36, background=CYAN, color=CYAN, line_width=0),
            label("qc-title", x + 16, y + 8, 200, 22, "Feed QC", size=16, color=TEXT, weight="bold"),
            label("qc-live", x + w - 78, y + 9, 64, 20, "● LIVE", size=12, color=LIVE, align="right", weight="bold"),
        ]
    )
    row_y = y + 48
    for index, (name, value) in enumerate(rows):
        if index % 2 == 0:
            pens.append(
                rect(
                    f"qc-row-{index}",
                    x + 8,
                    row_y - 2,
                    w - 16,
                    24,
                    background="#1a283c",
                    color="#1a283c",
                    line_width=0,
                    radius=4,
                )
            )
        pens.extend(
            [
                label(f"qc-k-{index}", x + 16, row_y, 170, 20, name, size=12, color=MUTED),
                label(f"qc-v-{index}", x + 180, row_y, 120, 20, value, size=13, color=TEXT, align="right", weight="bold"),
            ]
        )
        row_y += 26



def tip(pens: list[dict[str, Any]], pen_id: str, x: float, y: float) -> None:
    pens.append(
        {
            "id": pen_id,
            "name": "rightArrow",
            "x": snap(x),
            "y": snap(y) - 6,
            "width": 16,
            "height": 12,
            "color": PIPE,
            "background": PIPE,
            "disableAnchor": True,
        }
    )


def column(
    pens: list[dict[str, Any]],
    pen_id: str,
    x: float,
    y: float,
    w: float,
    h: float,
    trays: int,
) -> tuple[float, float, float, float]:
    """Place a 3D vertical vessel (IDMP Storage tank symbol), matching PI Vision style."""
    x, y, w, h = snap(x), snap(y), snap(w), snap(h)
    # Subtle silhouette behind the 3D asset so trayed "column" read still works if image scales.
    pens.append(
        rect(
            f"{pen_id}-silhouette",
            x + w * 0.18,
            y + 8,
            w * 0.64,
            h - 16,
            background="#9aa3ad",
            color="#cfd5dc",
            line_width=1,
            radius=w * 0.32,
        )
    )
    pens.append(image(f"{pen_id}-body", x, y, w, h, COLUMN))
    # Light tray marks for distillation read (on top of silhouette, under/near asset).
    for i in range(1, min(trays, 8) + 1):
        ty = y + (i / (min(trays, 8) + 1)) * h
        hv(
            pens,
            f"{pen_id}-tray-{i}",
            x + w * 0.28,
            ty,
            x + w * 0.72,
            ty,
            color="#6e7680",
            width=1.5,
            animated=False,
        )
    pens.append(
        label(
            f"{pen_id}-name",
            x - 8,
            y - 26,
            w + 16,
            22,
            "C-1309",
            size=15,
            color=CYAN,
            align="center",
            weight="bold",
        )
    )
    return x + w / 2, y, y + h / 2, y + h


def valve(
    pens: list[dict[str, Any]],
    pen_id: str,
    x: float,
    y: float,
    *,
    label_text: str,
    label_dy: float = 22,
) -> None:
    """3D ball valve on a horizontal pipe (wide metallic symbol like PI Vision)."""
    pens.extend(
        [
            image(pen_id, x, y - 14, 56, 28, VALVE),
            label(
                f"{pen_id}-name",
                x - 10,
                y + label_dy,
                76,
                18,
                label_text,
                size=13,
                color=CYAN,
                align="center",
                weight="bold",
            ),
        ]
    )


def pump_symbol(pens: list[dict[str, Any]], x: float, y: float) -> None:
    """Compact centrifugal-style pump built from available 3D tank geometry + nozzle."""
    pens.extend(
        [
            image("pump-body", x - 22, y - 30, 44, 60, PUMP_BODY),
            {
                "id": "pump-hub",
                "name": "circle",
                "x": x - 14,
                "y": y - 14,
                "width": 28,
                "height": 28,
                "background": "#b8c0c8",
                "color": "#e8eef4",
                "lineWidth": 2,
                "disableAnchor": True,
            },
            rect("pump-nozzle", x + 12, y - 6, 22, 12, background="#9aa3ad", color="#d7dee8", line_width=1, radius=2),
            label("pump-name", x - 50, y + 34, 100, 18, "P-24/09A", size=13, color=CYAN, align="center", weight="bold"),
        ]
    )


def pvsp(
    pens: list[dict[str, Any]],
    prefix: str,
    x: float,
    y: float,
    pv_attr: str,
    sp_attr: str | None,
    pv: str,
    sp: str,
) -> None:
    """Tight 2-row PV/SP block, always left-aligned on a grid."""
    pens.extend(
        [
            label(f"{prefix}-pl", x, y, 32, 18, "PV:", size=13, align="right", color=MUTED),
            live(f"{prefix}-pv", x + 36, y, 62, 18, pv_attr, pv, size=14, color=LIVE),
            label(f"{prefix}-pu", x + 100, y, 34, 18, "gpm", size=12, color=MUTED),
            label(f"{prefix}-sl", x, y + 20, 32, 18, "SP:", size=13, align="right", color=MUTED),
        ]
    )
    if sp_attr:
        pens.append(live(f"{prefix}-sp", x + 36, y + 20, 62, 18, sp_attr, sp, size=14, color=CYAN))
    else:
        pens.append(label(f"{prefix}-sp", x + 36, y + 20, 62, 18, sp, size=14, weight="bold", color=CYAN))
    pens.append(label(f"{prefix}-su", x + 100, y + 20, 34, 18, "gpm", size=12, color=MUTED))


def build_pens() -> list[dict[str, Any]]:
    pens: list[dict[str, Any]] = [
        rect("bg", 0, 0, WIDTH, HEIGHT, background=BG, color=BG, line_width=0),
        rect("frame", 20, 56, 1880, 860, background="#141c2b", color=FRAME, line_width=2),
        label("title", 40, 70, 480, 28, "Houston Refinery - Unit 3-1415", size=20, weight="bold"),
        # Dynamic LIVE chip — PI Vision doesn't move; this one does.
        rect("live-chip", 540, 72, 92, 26, background="#123528", color=LIVE, line_width=1.5, radius=13),
        label("live-chip-t", 540, 75, 92, 20, "● LIVE", size=13, color=LIVE, align="center", weight="bold"),
        label("live-sub", 644, 76, 280, 20, "streaming historian · 2s refresh", size=12, color=MUTED),
    ]

    # ---- Equipment anchors (10px grid) ----
    # Main tall column (short enough that Feed QC sits fully below it)
    main_x, main_y, main_w, main_h = 260, 150, 100, 400
    main_cx, main_top, main_mid, main_bot = column(pens, "main", main_x, main_y, main_w, main_h, 11)

    # Side shorter column
    side_x, side_y, side_w, side_h = 620, 240, 110, 260
    side_cx, side_top, side_mid, side_bot = column(pens, "side", side_x, side_y, side_w, side_h, 6)

    # Feed Sched / Actual — stacked flush left of feed line
    pens.extend(
        [
            rect("feed-badge", 40, 198, 168, 58, background="#15283c", color=ACCENT, line_width=1.5, radius=8),
            label("sched-l", 48, 206, 60, 18, "Sched:", size=14, align="right", color=MUTED),
            live("sched", 112, 206, 58, 18, "52FC001.SV", "2,536", size=15, color=CYAN),
            label("sched-u", 168, 206, 36, 18, "gpm", size=12, color=MUTED),
            label("actual-l", 48, 230, 60, 18, "Actual:", size=14, align="right", color=MUTED),
            live("actual", 112, 230, 58, 18, "52FC001.PV", "2,540", size=15, color=LIVE),
            label("actual-u", 168, 230, 36, 18, "gpm", size=12, color=MUTED),
        ]
    )

    # Feed in — thicker animated process line
    route(pens, "feed", [(40, main_mid), (main_x, main_mid)], width=5)
    tip(pens, "feed-tip", main_x - 18, main_mid)

    # Overhead return: side top → up → left → down into main top (all ortho)
    oh_y = 120
    route(
        pens,
        "oh",
        [
            (side_cx, side_top),
            (side_cx, oh_y),
            (main_cx, oh_y),
            (main_cx, main_top),
        ],
        dashed=True,
        width=3,
    )

    # Mid transfer through LC-780 — pure horizontal at main_mid / side_mid level (use main_mid)
    mid_y = 340
    route(pens, "mid", [(main_x + main_w, mid_y), (side_x, mid_y)], width=3)
    valve(pens, "lc-valve", 480, mid_y, label_text="LC-780")
    pvsp(pens, "lc780", 450, mid_y - 62, "54FC007.PV", "54FC007.SV", "2,489", "2,600")

    # FC-009 enters side vessel from the RIGHT on a horizontal line
    fc009_y = mid_y
    fc009_x = side_x + side_w
    route(pens, "fc009-run", [(fc009_x, fc009_y), (fc009_x + 160, fc009_y)], width=3)
    valve(pens, "fc009-valve", fc009_x + 40, fc009_y, label_text="FC-009")
    pvsp(pens, "fc009", fc009_x + 110, fc009_y - 50, "54FC001.PV", "54FC001.SV", "298", "300")

    # Bottoms of side → down → right through pump → vertical riser → 3 H branches
    pump_x = 780
    pump_y = 700
    header_x = 1100
    # Drop from side bottom to pump elevation, then to pump, then out to header
    route(
        pens,
        "bottoms",
        [
            (side_cx, side_bot),
            (side_cx, pump_y),
            (header_x, pump_y),
        ],
        width=3,
    )
    pump_symbol(pens, pump_x, pump_y)

    # Three perfectly aligned horizontal outlets off a vertical header
    branch_ys = [360, 470, 600]
    outlets = [
        ("FC-010", "Plant", "54FY026A.PV", "1,000", branch_ys[0]),
        ("FC-011", "", "54FY026B.PV", "900", branch_ys[1]),
        ("FC-012", "Storage", "54FY026C.PV", "900", branch_ys[2]),
    ]
    # Vertical header from top branch down to pump line
    route(pens, "hdr", [(header_x, branch_ys[0]), (header_x, pump_y)], width=3)

    valve_x = 1380
    end_x = 1860
    for index, (tag, dest, attr, sp, by) in enumerate(outlets, start=1):
        route(pens, f"br{index}", [(header_x, by), (end_x, by)], width=3)
        tip(pens, f"br{index}-tip", end_x - 2, by)
        pens.extend(
            [
                rect(
                    f"br{index}-box",
                    valve_x - 10,
                    by - 30,
                    70,
                    58,
                    background="rgba(27,34,48,0.2)",
                    color="#9eafc2",
                    line_width=1.25,
                    dash=[4, 3],
                ),
                image(f"br{index}-valve", valve_x - 4, by - 14, 56, 28, VALVE),
                label(
                    f"br{index}-tag",
                    valve_x - 10,
                    by + 24,
                    70,
                    16,
                    tag,
                    size=12,
                    color=CYAN,
                    align="center",
                    weight="bold",
                ),
            ]
        )
        if dest:
            pens.append(label(f"br{index}-dest", valve_x + 78, by - 28, 70, 18, dest, size=14, weight="bold"))
            pens.append(
                {
                    "id": f"br{index}-arr",
                    "name": "rightArrow",
                    "x": valve_x + 64,
                    "y": by - 25,
                    "width": 12,
                    "height": 10,
                    "color": TEXT,
                    "background": TEXT,
                    "disableAnchor": True,
                }
            )
        pvsp(pens, f"br{index}", valve_x + 160, by - 20, attr, None, "945", sp)

    # Feed QC card — fully below the main column (no symbol overlap)
    feed_qc_card(pens)

    # Footer — live NOW bar
    pens.extend(
        [
            rect("timebar", 20, 930, 1880, 50, background="#0c121c", color="#2b4570", line_width=1),
            label("t0", 40, 944, 260, 20, "9/20/2020 3:43:17 PM", size=12, color=MUTED),
            label("t8", 900, 944, 80, 20, "8h", size=13, color=TEXT, align="center", weight="bold"),
            label("t1", 1480, 944, 240, 20, "9/20/2020 11:43:17 PM", size=12, color=MUTED, align="right"),
            rect("now", 1760, 938, 70, 32, background=LIVE, color=LIVE, line_width=0, radius=6),
            label("now-t", 1760, 944, 70, 20, "NOW", size=12, color="#042016", align="center", weight="bold"),
        ]
    )
    return pens


def panel_placements() -> list[dict[str, Any]]:
    # One clean trend card — IDMP lePanelCard needs ~480×220+ or the chrome + series labels collide.
    # Product flows live in the open upper-right (reference position).
    return [
        {"panel": "product_flows", "x": 980, "y": 90, "w": 520, "h": 230},
        # Clear bottom-right lane under the outlet stack (not over the pump riser).
        {"panel": "feed_flow", "x": 1120, "y": 760, "w": 480, "h": 150},
    ]


def main() -> None:
    output = Path(__file__).with_name("display.json")
    display: dict[str, Any] = {
        "name": DISPLAY_NAME,
        "description": "Orthogonal precision recreation of PI Vision Houston Unit 3-1415.",
        "element_id": ELEMENT_ID,
        "dashboard_type": "canvas",
        "theme": "process",
        "refresh_seconds": 2,
        "time_from": "now-8h",
        "time_to": "now",
        "header_html": (
            "<div style='height:100%;box-sizing:border-box;padding:8px 16px;"
            "display:flex;align-items:center;gap:16px;"
            "background:linear-gradient(90deg,#0b1524,#152a45 55%,#0f2a22);"
            "border-bottom:1px solid #2f6b8f;color:#e8eef6;"
            "font-family:ui-sans-serif,system-ui,sans-serif'>"
            "<div style='font-size:14px;font-weight:700;letter-spacing:.2px'>TDengine IDMP</div>"
            "<div style='font-size:12px;color:#9eb0c3'>Migrated from PI Vision · Unit 3-1415</div>"
            "<div style='margin-left:auto;display:flex;align-items:center;gap:10px'>"
            "<span style='padding:3px 10px;border-radius:999px;background:#123528;"
            "border:1px solid #5dffb0;color:#5dffb0;font-size:11px;font-weight:700'>"
            "● LIVE STREAM</span>"
            "<span style='font-size:11px;color:#3dd6ff'>editable Canvas · animated flow</span>"
            "</div></div>"
        ),
        "canvas": {
            "width": WIDTH,
            "height": HEIGHT,
            "background": BG,
            "text_color": TEXT,
            "line_width": 4,
            "network_interval": 1,
            "header_placement": {"x": 20, "y": 8, "w": 1880, "h": 40},
            "pens": build_pens(),
            "panel_placements": panel_placements(),
        },
    }
    if DASHBOARD_ID:
        display["dashboard_id"] = DASHBOARD_ID
    # Assert every line pen is orthogonal
    for pen in display["canvas"]["pens"]:
        if pen.get("name") == "line":
            w, h = float(pen["width"]), float(pen["height"])
            if w > 1 and h > 1:
                raise AssertionError(f"Diagonal line slipped through: {pen['id']} {w}x{h}")
    output.write_text(json.dumps(display, indent=2), encoding="utf-8")
    print(f"Wrote {output} with {len(display['canvas']['pens'])} pens (all ortho)")


if __name__ == "__main__":
    main()
